const preloader=document.querySelector("#preloader");
window.addEventListener("load",()=>setTimeout(()=>preloader.classList.add("hide"),700));

const glow=document.querySelector(".cursor-glow");
window.addEventListener("mousemove",e=>{
  glow.style.left=e.clientX+"px";
  glow.style.top=e.clientY+"px";
});

const observer=new IntersectionObserver(entries=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  })
},{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));

const titleObserver=new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(e.isIntersecting){
      e.target.querySelectorAll("h1, i, b").forEach((el,i)=>{
        el.animate(
          [{transform:"translateY(110%) rotate(2deg)",opacity:0},{transform:"translateY(0) rotate(0)",opacity:1}],
          {duration:950,delay:i*110,easing:"cubic-bezier(.2,.8,.2,1)",fill:"forwards"}
        );
      });
      titleObserver.unobserve(e.target);
    }
  })
},{threshold:.15});
document.querySelectorAll(".hero-title,.contact-title").forEach(el=>titleObserver.observe(el));

document.querySelectorAll(".magnetic").forEach(el=>{
  el.addEventListener("mousemove",e=>{
    const r=el.getBoundingClientRect();
    const x=e.clientX-r.left-r.width/2;
    const y=e.clientY-r.top-r.height/2;
    el.style.transform=`translate(${x*.15}px,${y*.15}px)`;
  });
  el.addEventListener("mouseleave",()=>el.style.transform="translate(0,0)");
});

document.querySelectorAll(".tilt .project-media").forEach(card=>{
  card.addEventListener("mousemove",e=>{
    const r=card.getBoundingClientRect();
    const x=(e.clientX-r.left)/r.width-.5;
    const y=(e.clientY-r.top)/r.height-.5;
    card.style.transform=`perspective(900px) rotateY(${x*3}deg) rotateX(${-y*3}deg) scale(.992)`;
  });
  card.addEventListener("mouseleave",()=>card.style.transform="");
});

const statObserver=new IntersectionObserver(entries=>{
  entries.forEach(entry=>{
    if(!entry.isIntersecting)return;
    const el=entry.target;
    const target=+el.dataset.count;
    const duration=1300;
    const start=performance.now();
    function tick(now){
      const p=Math.min((now-start)/duration,1);
      const eased=1-Math.pow(1-p,3);
      el.textContent=Math.floor(target*eased);
      if(p<1) requestAnimationFrame(tick);
      else el.textContent=target;
    }
    requestAnimationFrame(tick);
    statObserver.unobserve(el);
  });
},{threshold:.5});
document.querySelectorAll("[data-count]").forEach(el=>statObserver.observe(el));

let lastY=window.scrollY;
const nav=document.querySelector(".nav");
window.addEventListener("scroll",()=>{
  const y=window.scrollY;
  nav.style.transform=(y>lastY && y>180)?"translateY(-110%)":"translateY(0)";
  nav.style.transition="transform .45s ease";
  lastY=y;
});

document.querySelectorAll(".project-play").forEach(btn=>{
  btn.addEventListener("click",()=>{
    alert("Aqui você pode abrir o vídeo do projeto em um modal ou link do YouTube/Vimeo.");
  });
});
